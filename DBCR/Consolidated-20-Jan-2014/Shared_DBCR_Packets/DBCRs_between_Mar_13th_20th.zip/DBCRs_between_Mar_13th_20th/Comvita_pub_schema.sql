--------------------------Mar 13th 2014 - Neeraj Garg 2 <ngarg13@sapient.com>

ALTER TABLE SGS_DPS_USER ADD (logged_in NUMBER(1,0) , migrated_account NUMBER(1,0) );
