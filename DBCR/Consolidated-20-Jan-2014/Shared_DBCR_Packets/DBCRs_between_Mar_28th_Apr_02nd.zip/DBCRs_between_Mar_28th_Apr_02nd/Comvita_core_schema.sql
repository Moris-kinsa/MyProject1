--------------------------Mar 31st 2014 - Bharat Mendiratta 2 <bmendiratta2@sapient.com>
ALTER TABLE DCS_GIFTITEM MODIFY DESCRIPTION VARCHAR2(1200);