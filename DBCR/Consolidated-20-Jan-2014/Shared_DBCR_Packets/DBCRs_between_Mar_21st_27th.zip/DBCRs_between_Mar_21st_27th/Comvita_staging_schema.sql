--------------------------Mar 27th 2014 - Rajendra Singh 3 <rsingh93@sapient.com>
ALTER TABLE sgs_address ADD (state_address VARCHAR2(40));